# first rest call to get all repos 
$firstcall = Invoke-RestMethod "https://api.github.com/users/mayankdevops/repos"
#echo $firstcall
#$json1.psobject.properties.name
#$x = $json1.Stuffs

foreach ($firstcall in $firstcall.name) {
echo $firstcall
# second call to get commit details for all repos fetched from first call
$secondcall = Invoke-RestMethod "https://api.github.com/repos/mayankdevops/$firstcall/commits"
foreach ($secondcall in $secondcall) {

$reponame = $firstcall
$commitId = $secondcall.sha
$authorName = $secondcall.commit.author.name
$commitMessage = $secondcall.commit.message
$commiTime = $secondcall.commit.author.date
echo $commitId
<# echo $commitId
echo $authorName
echo $commitMessage
echo $commiTime #>
add-content C:\Mayank\json\final\git\Git_Cypher.txt "CREATE (:GIT {RepoName:'$reponame', ScmRevisionNumber:'$commitId', ScmAuthor:'$authorName' , ScmCommitLog:'$commitMessage',  ScmCommitTimestamp:'$commiTime'})"
}
}
#Get-content C:\Mayank\json\Jenkins_Cypher.txt
#CREATE (Keanu:Person {name:'Keanu Reeves', born:1964})

#CREATE (SampleProject:JENKINS {jobname:SampleProject, number:74})
#CREATE (n:Person { name : 'Andres', title : 'Developer' })
#$buildnumber = $i.lastBuild.number
#echo $buildnumber
#$commitid = $i.lastBuild.changeSet.items.commitid
#echo $commitid

#write-host "CREATE (jenkins" -nonewline ; write-host ":JENKINS { jobname : '$jobname', number : '$buildnumber' })"
#add-content C:\Mayank\json\Jenkins_Cypher.txt "CREATE (jenkins:JENKINS { jobname : '$jobname', number : '$buildnumber' })"