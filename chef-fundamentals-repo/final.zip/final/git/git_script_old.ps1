# This is my first powershell script
#$firstcall = Invoke-RestMethod "https://api.github.com/repos/mayankdevops/onlinebanking/commits"

$gitjson = (Get-Content "git_json.json" -Raw) | ConvertFrom-Json
#$json1.psobject.properties.name
#$x = $json1.Stuffs
foreach ($i in $gitjson) {
$commitId = $i.sha
$authorName = $i.commit.author.name
$commitMessage = $i.commit.message
$commiTime = $i.commit.author.date

echo $commitId
echo $authorName
echo $commitMessage
echo $commiTime
add-content C:\Mayank\json\final\git\Git_Cypher.txt "CREATE (git:GIT {ScmRevisionNumber:'$commitId', ScmAuthor:'$authorName' , ScmCommitLog:'$commitMessage',  ScmCommitTimestamp:'$commiTime'})"
}
#Get-content C:\Mayank\json\Jenkins_Cypher.txt
#CREATE (Keanu:Person {name:'Keanu Reeves', born:1964})

#CREATE (SampleProject:JENKINS {jobname:SampleProject, number:74})
#CREATE (n:Person { name : 'Andres', title : 'Developer' })
#$buildnumber = $i.lastBuild.number
#echo $buildnumber
#$commitid = $i.lastBuild.changeSet.items.commitid
#echo $commitid

#write-host "CREATE (jenkins" -nonewline ; write-host ":JENKINS { jobname : '$jobname', number : '$buildnumber' })"
#add-content C:\Mayank\json\Jenkins_Cypher.txt "CREATE (jenkins:JENKINS { jobname : '$jobname', number : '$buildnumber' })"