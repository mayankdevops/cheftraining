# This is my first powershell script
$jenkinsjson = (Get-Content "jenkins_json.json" -Raw) | ConvertFrom-Json

#$firstcall = Invoke-RestMethod "http://ctsc00607758201:8080/api/json?tree=jobs[name,lastBuild[number]]"
#$jenkinsxml = (Get-Content "config.xml") | ConvertTo-Json -Compress
#$jenkinsxml = $jenkinsxml | ConvertFrom-Json

#$json1.psobject.properties.name
#$x = $json1.Stuffs
foreach ($i in $jenkinsjson.jobs) {
$jobName = $i.name

$jenkinsxml = (Get-Content "$jobName.json" -Raw) | ConvertFrom-Json
#echo $jenkinsxml."maven2-moduleset"."publishers"."org.jenkinsci.plugins.rundeck.RundeckNotifier"."jobId"

$buildNumber = $i.lastBuild.id
$result = $i.lastBuild.result
$timeStamp = $i.lastBuild.timestamp
$buildUrl = $i.lastBuild.url
$shorDesc = $i.lastBuild.actions.causes.shortDescription
$SCMCommitId = $i.lastBuild.changeSet.items.commitid
$SCMAuthor = $i.lastBuild.changeSet.items.author.fullName
$SCMComment = $i.lastBuild.changeSet.items.comment
$SCMKind = $i.lastBuild.changeSet.kind
$SonarUrl = $i.lastBuild.actions.url
$RundeckJobId = $jenkinsxml."maven2-moduleset"."publishers"."org.jenkinsci.plugins.rundeck.RundeckNotifier"."jobId"
$SCMRemoteUrl = $jenkinsxml."maven2-moduleset"."scm"."userRemoteConfigs"."hudson.plugins.git.UserRemoteConfig"."url"
$NexusRepo = $jenkinsxml."maven2-moduleset"."publishers"."hudson.maven.RedeployPublisher"."url"
$GroupId = $jenkinsxml."maven2-moduleset"."rootModule"."groupId"
$ArtifactId = $jenkinsxml."maven2-moduleset"."rootModule"."artifactId"

echo $jobName
echo $buildNumber
echo $result
echo $timeStamp
echo $shorDesc
echo $SCMCommitId
echo $SCMAuthor
echo $SCMComment
echo $SCMKind
echo $SonarUrl
echo $RundeckJobId
echo $SCMRemoteUrl
echo $NexusRepo
echo $GroupId
echo $ArtifactId
add-content C:\Mayank\json\final\jenkins\Jenkins_Cypher.txt "CREATE (jenkins:JENKINS { JobName :'$jobName', BuildNumber:'$buildNumber', Result:'$result', TimeStamp:'$timeStamp', StartedBy:'$shorDesc', SCMCommitId:'$SCMCommitId', SCMAuthor:'$SCMAuthor', SCMComment:'$SCMComment', SCMKind:'$SCMKind', SonarUrl:'$SonarUrl', RundeckJobId:'$RundeckJobId', SCMRemoteUrl:'$SCMRemoteUrl' , NexusRepo:'$NexusRepo', GroupId:'$GroupId', ArtifactId:'$ArtifactId'})"
}
#Get-content C:\Mayank\json\Jenkins_Cypher.txt
#CREATE (Keanu:Person {name:'Keanu Reeves', born:1964})

#CREATE (SampleProject:JENKINS {jobname:SampleProject, number:74})
#CREATE (n:Person { name : 'Andres', title : 'Developer' })
#$buildnumber = $i.lastBuild.number
#echo $buildnumber
#$commitid = $i.lastBuild.changeSet.items.commitid
#echo $commitid

#write-host "CREATE (jenkins" -nonewline ; write-host ":JENKINS { jobname : '$jobname', number : '$buildnumber' })"
#add-content C:\Mayank\json\Jenkins_Cypher.txt "CREATE (jenkins:JENKINS { jobname : '$jobname', number : '$buildnumber' })"