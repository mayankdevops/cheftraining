# First rest call to get all projects
$firstcall = Invoke-RestMethod "http://10.155.143.184:4440/api/15/projects/?authtoken=xQQmCgfwActEkdKYdaBwmIsJP8vqrYLG&format=json"

#loop through all the projects one by one
foreach ($firstcall in $firstcall.name) {
	#get all the data for all executions for the project
	$secondcall = Invoke-RestMethod "http://10.155.143.184:4440/api/15/project/$firstcall/executions?authtoken=xQQmCgfwActEkdKYdaBwmIsJP8vqrYLG&format=json&begin=1457004789378"	

	# get data for each execution project wise one by one
	foreach ($secondcall in $secondcall.executions) {
		# get required parameters populated
		$ProjectName = $secondcall.project
		$JobName = $secondcall.job.name
		$ExecutionId = $secondcall.id
		$JobId = $secondcall.job.id
		$Status = $secondcall.job.status
		$SuccessNodes = $secondcall.successfulNodes
		$FailNodes = $secondcall.failedNodes
		$DateStarted = $secondcall."date-started".unixtime
		$DateEnded = $secondcall."date-ended".unixtime
		$PermaLink = $secondcall.permalink
		$User = $secondcall.user
		
		# Create a text file with all Cypher querries to created Rundeck Node dump
		add-content C:\Mayank\json\final\rundeck\Rundeck_Cypher.txt "CREATE (:RUNDECK {ProjectName:'$ProjectName', JobName:'$JobName' , ExecutionId:'$ExecutionId', JobId:'$JobId', Status:'$Status', SuccessNodes:'$SuccessNodes', FailNodes:'$FailNodes', DateStarted:'$DateStarted', DateEnded:'$DateEnded', PermaLink:'$PermaLink', User:'$User'})"
}
}



#echo $secondcall.executions.project
#echo $secondcall.executions.id
#echo $secondcall.executions.job.name
#echo $secondcall.executions.job.id
#echo $secondcall.executions.job.status
#echo $secondcall.executions.successfulNodes
#echo $secondcall.executions.failedNodes
#echo $secondcall.executions."date-started".unixtime
#echo $secondcall.executions."date-ended".unixtime
#echo $secondcall.executions.permalink
#echo $secondcall.executions.user
#add-content C:\Mayank\json\final\rundeck\Rundeck_Cypher.txt "CREATE (rundeck:RUNDECK {ProjectName:'$ProjectName', JobName:'$secondcall.executions.job.name' , ExecutionId:'$secondcall.executions.id',  JobId:'$secondcall.executions.job.id'})"

#Get-content C:\Mayank\json\Jenkins_Cypher.txt
#CREATE (Keanu:Person {name:'Keanu Reeves', born:1964})

#CREATE (SampleProject:JENKINS {jobname:SampleProject, number:74})
#CREATE (n:Person { name : 'Andres', title : 'Developer' })
#$buildnumber = $i.lastBuild.number
#echo $buildnumber
#$commitid = $i.lastBuild.changeSet.items.commitid
#echo $commitid

#write-host "CREATE (jenkins" -nonewline ; write-host ":JENKINS { jobname : '$jobname', number : '$buildnumber' })"
#add-content C:\Mayank\json\Jenkins_Cypher.txt "CREATE (jenkins:JENKINS { jobname : '$jobname', number : '$buildnumber' })"