# First rest call to get all projects
$firstcall = Invoke-RestMethod "http://ctsc00607758201:9000/sonar/api/projects/index?format=json"
echo $firstcall.k
#loop through all the projects one by one
foreach ($firstcall in $firstcall.k) {
	#get all the data for all executions for the project
	$secondcall = Invoke-RestMethod "http://ctsc00607758201:9000/sonar/api/timemachine/index?metrics=complexity,coverage,new_coverage,duplicated_blocks,duplicated_files,duplicated_line,new_violations,sqale_index,sqale_debt_ratio,new_sqale_debt_ratio&resource=$firstcall&format=json"	
$Metrics = $secondcall.cols.metric
echo $secondcall.cells
	# get data for each execution project wise one by one
 	foreach ($secondcall in $secondcall.cells) {
		# get required parameters populated
		$Resourcekey = $firstcall
		$Timestamp = $secondcall.d
		#$Metrics = $secondcall.id
		$Value = $secondcall.v
				
		# Create a text file with all Cypher querries to created Rundeck Node dump
		add-content C:\Mayank\json\final\sonar\Sonar_Cypher.txt "CREATE (:SONAR {Resourcekey:'$Resourcekey', Timestamp:'$Timestamp' , Metrics:'$Metrics', Value:'$Value'})"
}
} 



#echo $secondcall.executions.project
#echo $secondcall.executions.id
#echo $secondcall.executions.job.name
#echo $secondcall.executions.job.id
#echo $secondcall.executions.job.status
#echo $secondcall.executions.successfulNodes
#echo $secondcall.executions.failedNodes
#echo $secondcall.executions."date-started".unixtime
#echo $secondcall.executions."date-ended".unixtime
#echo $secondcall.executions.permalink
#echo $secondcall.executions.user
#add-content C:\Mayank\json\final\rundeck\Rundeck_Cypher.txt "CREATE (rundeck:RUNDECK {ProjectName:'$ProjectName', JobName:'$secondcall.executions.job.name' , ExecutionId:'$secondcall.executions.id',  JobId:'$secondcall.executions.job.id'})"

#Get-content C:\Mayank\json\Jenkins_Cypher.txt
#CREATE (Keanu:Person {name:'Keanu Reeves', born:1964})

#CREATE (SampleProject:JENKINS {jobname:SampleProject, number:74})
#CREATE (n:Person { name : 'Andres', title : 'Developer' })
#$buildnumber = $i.lastBuild.number
#echo $buildnumber
#$commitid = $i.lastBuild.changeSet.items.commitid
#echo $commitid

#write-host "CREATE (jenkins" -nonewline ; write-host ":JENKINS { jobname : '$jobname', number : '$buildnumber' })"
#add-content C:\Mayank\json\Jenkins_Cypher.txt "CREATE (jenkins:JENKINS { jobname : '$jobname', number : '$buildnumber' })"